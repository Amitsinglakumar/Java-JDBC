This repositry basicallly focuses in the connection of mysql by JDBC.
